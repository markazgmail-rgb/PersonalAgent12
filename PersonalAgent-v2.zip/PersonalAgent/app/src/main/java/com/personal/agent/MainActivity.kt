package com.personal.agent

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var provider: Spinner
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var baseUrl: EditText
    private lateinit var task: EditText
    private lateinit var vision: CheckBox
    private lateinit var steps: EditText

    private val providers = arrayOf("claude", "openai")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Prefs.load(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 60, 40, 40)

        fun label(s: String) {
            val t = TextView(this)
            t.text = s
            t.textSize = 14f
            t.setPadding(0, 24, 0, 4)
            root.addView(t)
        }

        fun edit(value: String, hint: String): EditText {
            val e = EditText(this)
            e.setText(value)
            e.hint = hint
            e.isSingleLine = true
            root.addView(e)
            return e
        }

        val title = TextView(this)
        title.text = "Personal Agent"
        title.textSize = 24f
        root.addView(title)

        status = TextView(this)
        status.setPadding(0, 16, 0, 8)
        root.addView(status)

        val accBtn = Button(this)
        accBtn.text = "Accessibility settings kholo"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(accBtn)

        label("AI provider")
        provider = Spinner(this)
        provider.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Claude (Anthropic)", "OpenAI-compatible (GPT, Gemini, DeepSeek...)")
        )
        provider.setSelection(if (cfg.provider == "openai") 1 else 0)
        root.addView(provider)

        label("API key")
        key = edit(cfg.apiKey, "sk-...")
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        label("Model")
        model = edit(cfg.model, "model name")

        label("Base URL (shudhu OpenAI-compatible hole)")
        baseUrl = edit(cfg.baseUrl, "https://api.openai.com/v1")

        provider.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                baseUrl.isEnabled = pos == 1
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        label("Screenshot (vision): AI screen-er chhobi-o dekhbe. Design/chhobi/game-er kajer jonno dorkar, API khoroch ektu bare.")
        vision = CheckBox(this)
        vision.text = "Screenshot pathao"
        vision.isChecked = cfg.vision
        root.addView(vision)

        label("Ekta kaj-e max koyta step")
        steps = edit(cfg.maxSteps.toString(), "60")
        steps.inputType = InputType.TYPE_CLASS_NUMBER

        label("Ki kaj korbo? (likho ba mic e bolo)")
        task = EditText(this)
        task.hint = "Jemon: WhatsApp e Rahim ke bolo ami 10 minute e ashchi"
        task.minLines = 2
        root.addView(task)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val mic = Button(this)
        mic.text = "Mic"
        mic.setOnClickListener { listen() }
        val go = Button(this)
        go.text = "Shuru koro"
        go.setOnClickListener { startTask() }
        val stop = Button(this)
        stop.text = "Stop"
        stop.setOnClickListener { AgentService.instance?.stop() }
        row.addView(mic)
        row.addView(go)
        row.addView(stop)
        root.addView(row)

        logView = TextView(this)
        logView.textSize = 13f
        logView.setPadding(0, 24, 0, 0)
        logView.setTextIsSelectable(true)
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val on = AgentService.instance != null
        status.text = if (on) "Accessibility: chalu (ready)" else "Accessibility: bondho. Age chalu korte hobe."
        logView.text = AgentLog.snapshot()
        AgentLog.listener = { line -> logView.append("\n" + line) }
    }

    override fun onPause() {
        super.onPause()
        AgentLog.listener = null
    }

    private fun currentConfig(): AgentConfig = AgentConfig(
        provider = providers[provider.selectedItemPosition],
        apiKey = key.text.toString().trim(),
        model = model.text.toString().trim(),
        baseUrl = baseUrl.text.toString().trim(),
        vision = vision.isChecked,
        maxSteps = (steps.text.toString().trim().toIntOrNull() ?: 60).coerceIn(5, 200)
    )

    private fun startTask() {
        val svc = AgentService.instance
        if (svc == null) {
            Toast.makeText(this, "Age Accessibility service chalu koro", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val cfg = currentConfig()
        val t = task.text.toString().trim()
        if (cfg.apiKey.isEmpty() || cfg.model.isEmpty() || t.isEmpty()) {
            Toast.makeText(this, "API key, model ar kaj likho", Toast.LENGTH_LONG).show()
            return
        }
        if (svc.isRunning()) {
            Toast.makeText(this, "Ekta kaj cholche", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.save(this, cfg)
        logView.text = ""
        AgentLog.lines.clear()
        svc.start(t, cfg)
    }

    @Suppress("DEPRECATION")
    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        try {
            startActivityForResult(i, 1)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Ei phone e voice input nai", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!r.isNullOrEmpty()) task.setText(r[0])
        }
    }
}
