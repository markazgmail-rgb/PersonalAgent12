package com.personal.agent

import android.content.Context
import android.os.Handler
import android.os.Looper

data class AgentConfig(
    val provider: String,   // "claude" or "openai"
    val apiKey: String,
    val model: String,
    val baseUrl: String,
    val vision: Boolean = true,   // screenshot pathabe ki na
    val maxSteps: Int = 60
)

object Prefs {
    private const val FILE = "agent_prefs"

    fun load(ctx: Context): AgentConfig {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return AgentConfig(
            provider = p.getString("provider", "claude") ?: "claude",
            apiKey = p.getString("apiKey", "") ?: "",
            model = p.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5",
            baseUrl = p.getString("baseUrl", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
            vision = p.getBoolean("vision", true),
            maxSteps = p.getInt("maxSteps", 60)
        )
    }

    fun save(ctx: Context, c: AgentConfig) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("provider", c.provider)
            .putString("apiKey", c.apiKey)
            .putString("model", c.model)
            .putString("baseUrl", c.baseUrl)
            .putBoolean("vision", c.vision)
            .putInt("maxSteps", c.maxSteps)
            .apply()
    }

    /** Agent-er nijer "remember" kora note (phone-e thake). */
    fun notes(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("notes", "") ?: ""

    fun addNote(ctx: Context, note: String) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val all = ((p.getString("notes", "") ?: "") + "\n- " + note.trim()).trim()
        p.edit().putString("notes", all.takeLast(4000)).apply()
    }

    fun clearNotes(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove("notes").apply()
    }
}

object AgentLog {
    private val main = Handler(Looper.getMainLooper())
    val lines = ArrayList<String>()

    @Volatile
    var listener: ((String) -> Unit)? = null

    fun add(s: String) {
        synchronized(lines) {
            lines.add(s)
            if (lines.size > 200) lines.removeAt(0)
        }
        main.post { listener?.invoke(s) }
    }

    fun snapshot(): String = synchronized(lines) { lines.joinToString("\n") }
}
