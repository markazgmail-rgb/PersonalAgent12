# Personal Agent

Phone-e tumi kaj bolbe (likhe ba mic e), AI screen dekhe app khule tap/type kore kaj kore dibe.
AI provider: Claude (Anthropic) ba OpenAI-compatible (GPT, Gemini, DeepSeek...). Tomar nijer API key lagbe.

## APK banano (free, GitHub diye)
1. github.com e notun private repo banao, ei folder-er shob file upload/push koro (branch: main).
2. Repo-r **Actions** tab -> "Build APK" -> run hole shesh e **Artifacts** theke `PersonalAgent-apk` download koro, zip khule `app-debug.apk` pao.
(Android Studio thakle folder open kore Run-o korte paro.)

## Phone-e chalu korar niyom
1. APK install koro (Unknown sources allow).
2. Android 13+ hole: Settings -> Apps -> Personal Agent -> ⋮ (3 dot) -> **Allow restricted settings**.
3. App-e "Accessibility settings kholo" -> Personal Agent -> chalu koro.
4. API key, model dao -> kaj likho -> **Shuru koro**.
Kaj cholar shomoy screen-e lal **STOP** button thakbe.

## Notun (v2) — ki ki pare
- **Screenshot dekhe kaj**: AI ekhon screen-er chhobi-o dekhe (Android 11+). Tai logo/design/photo/video app, canvas, game, map-e kaj kora jay. (Settings-e "Screenshot pathao" on/off.)
- **Notun tool**: tap, long_press, swipe/drag (ankar jonno), submit (Enter/Search), set_clipboard + paste, open_url, dial, remember (tomar kotha mone rakhe).
- Max step 60 (settings-e 5-200 kora jay).
- Jemon bolte paro: "Canva khule ekta professional logo banao, naam 'Noor Traders', shobuj-shona rong, gallery-te save koro".
- Sob dhoroner kaj ekdom nikhut hobe na: AI-r model joto bhalo, kaj toto bhalo. Chhobi-bujhte pare emon model (Claude Sonnet/Opus, GPT-4o+ etc.) bebohar koro.

## Nirapotta
- Sensitive kaj (message pathano, kena, delete, post) -er age AI tomar hyan/na confirm chay.
- Password, OTP, PIN AI likhbe na; password field AI-ke dekhano hoy na.
- Screen-er likha (web page, message) AI-er jonno data, hukum noy.
- API key phone-e plain SharedPreferences-e thake. Shudhu nijer phone-e use koro.
- Screen-er text tomar API provider-er kache jay. Banking/private app-e use korar age bhebe nio.

## Shimabodhota
- Android 10 ba tar niche screenshot kaj kore na (shudhu text); Android 11+ e kore.
- Kichu app (banking, FLAG_SECURE) accessibility block kore.
- Screenshot pathale API khoroch beshi hoy (protita step-e ekta chhobi jay).
