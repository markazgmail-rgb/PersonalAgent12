package com.personal.agent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

const val SCREEN_MARK = "--- SCREEN ---"

/** Neutral conversation turn, converted to each provider's format on the fly. */
class Turn(
    val kind: Int,
    val text: String = "",
    val id: String = "",
    val name: String = "",
    val args: JSONObject? = null,
    val image: String? = null   // base64 JPEG (shudhu newest observation-e pathano hoy)
) {
    companion object {
        const val USER = 0
        const val CALL = 1
        const val RESULT = 2
    }
}

class ToolCall(val id: String, val name: String, val args: JSONObject)

object Tools {
    class Def(val name: String, val desc: String, val schema: JSONObject)

    private fun def(
        name: String,
        desc: String,
        required: List<String>,
        vararg props: Triple<String, String, String>
    ): Def {
        val p = JSONObject()
        p.put(
            "reason",
            JSONObject().put("type", "string").put("description", "One short sentence: why you do this step")
        )
        for ((n, t, d) in props) {
            p.put(n, JSONObject().put("type", t).put("description", d))
        }
        val s = JSONObject()
            .put("type", "object")
            .put("properties", p)
            .put("required", JSONArray(required + "reason"))
        return Def(name, desc, s)
    }

    val all: List<Def> = listOf(
        def(
            "open_app", "Launch an installed app by its name.", listOf("name"),
            Triple("name", "string", "App name as shown on the phone, e.g. WhatsApp, Chrome, Messages")
        ),
        def(
            "click", "Click an element from the numbered screen list.", listOf("index"),
            Triple("index", "integer", "Element number in square brackets")
        ),
        def(
            "tap", "Tap screen coordinates (screenshot space). Use when no element index works, e.g. canvas, images, games, custom UI.", listOf("x", "y"),
            Triple("x", "integer", "X in screenshot space"), Triple("y", "integer", "Y in screenshot space")
        ),
        def(
            "type_text", "Type text into an input element (replaces its current text).", listOf("index", "text"),
            Triple("index", "integer", "Element number of the input field"),
            Triple("text", "string", "Text to enter")
        ),
        def(
            "long_press", "Press and hold at screen coordinates (select text, drag handles, context menus).", listOf("x", "y"),
            Triple("x", "integer", "X in screenshot space"), Triple("y", "integer", "Y in screenshot space")
        ),
        def(
            "swipe", "Swipe/drag from one point to another (scroll precisely, drag sliders, move objects, draw on canvas).",
            listOf("x1", "y1", "x2", "y2"),
            Triple("x1", "integer", "Start X"), Triple("y1", "integer", "Start Y"),
            Triple("x2", "integer", "End X"), Triple("y2", "integer", "End Y"),
            Triple("ms", "integer", "Duration in ms, 100-3000 (default 400). Longer = slower drag.")
        ),
        def(
            "submit", "Press the keyboard's Enter/Search/Go action on an input field (Android 11+).", listOf("index"),
            Triple("index", "integer", "Element number of the input field")
        ),
        def(
            "set_clipboard", "Put text on the clipboard (useful for long text, then use paste).", listOf("text"),
            Triple("text", "string", "Text to copy")
        ),
        def(
            "paste", "Paste the clipboard into an input element.", listOf("index"),
            Triple("index", "integer", "Element number of the input field")
        ),
        def(
            "open_url", "Open a web link or deep link (https://, geo:, mailto:...) in the right app.", listOf("url"),
            Triple("url", "string", "Full URL")
        ),
        def(
            "dial", "Open the phone dialer with a number filled in (does NOT place the call).", listOf("number"),
            Triple("number", "string", "Phone number")
        ),
        def(
            "remember", "Save a short durable note about the owner (contacts, preferences, app habits) for future tasks.", listOf("note"),
            Triple("note", "string", "One short fact worth remembering")
        ),
        def(
            "scroll", "Scroll the screen to reveal more content.", listOf("direction"),
            Triple("direction", "string", "down, up, left or right. 'down' reveals content further down the page")
        ),
        def(
            "press", "Press a system key.", listOf("key"),
            Triple("key", "string", "back, home, recents or notifications")
        ),
        def(
            "wait", "Wait while something loads.", listOf("seconds"),
            Triple("seconds", "integer", "1 to 10")
        ),
        def(
            "confirm",
            "Ask the user yes/no BEFORE any sensitive or irreversible action (send, pay, buy, delete, post, call, change settings). Returns 'yes' or 'no'.",
            listOf("message"),
            Triple("message", "string", "Clear summary of exactly what you are about to do, in the user's language")
        ),
        def(
            "finish", "End the task: done, impossible, or you need something from the user.", listOf("message", "success"),
            Triple("message", "string", "Final message for the user, in the user's language"),
            Triple("success", "boolean", "true if the task was completed")
        )
    )
}

class LlmClient(private val cfg: AgentConfig) {

    fun next(system: String, turns: List<Turn>): ToolCall =
        if (cfg.provider == "claude") claude(system, turns) else openai(system, turns)

    /** Only the newest observation keeps its full screen dump, older ones are shortened. */
    private fun body(t: Turn, isLast: Boolean): String {
        val i = t.text.indexOf(SCREEN_MARK)
        return if (isLast || i < 0) t.text else t.text.substring(0, i) + "[older screen omitted]"
    }

    /** Text-only hole string, image thakle [text, image] array. */
    private fun claudeContent(text: String, image: String?): Any {
        if (image == null) return text
        return JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", image)
                )
            )
    }

    private fun openaiImage(text: String, image: String): JSONArray = JSONArray()
        .put(JSONObject().put("type", "text").put("text", text))
        .put(
            JSONObject().put("type", "image_url").put(
                "image_url", JSONObject().put("url", "data:image/jpeg;base64,$image")
            )
        )

    private fun claude(system: String, turns: List<Turn>): ToolCall {
        val msgs = JSONArray()
        turns.forEachIndexed { i, t ->
            val last = i == turns.size - 1
            when (t.kind) {
                Turn.USER -> msgs.put(JSONObject().put("role", "user").put("content", claudeContent(body(t, last), if (last) t.image else null)))
                Turn.CALL -> msgs.put(
                    JSONObject().put("role", "assistant").put(
                        "content",
                        JSONArray().put(
                            JSONObject().put("type", "tool_use").put("id", t.id)
                                .put("name", t.name).put("input", t.args)
                        )
                    )
                )
                else -> msgs.put(
                    JSONObject().put("role", "user").put(
                        "content",
                        JSONArray().put(
                            JSONObject().put("type", "tool_result").put("tool_use_id", t.id)
                                .put("content", claudeContent(body(t, last), if (last) t.image else null))
                        )
                    )
                )
            }
        }
        val tools = JSONArray()
        for (d in Tools.all) {
            tools.put(
                JSONObject().put("name", d.name).put("description", d.desc).put("input_schema", d.schema)
            )
        }
        val req = JSONObject()
            .put("model", cfg.model)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("tools", tools)
            .put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", msgs)

        val resp = JSONObject(
            post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01"),
                req.toString()
            )
        )
        val content = resp.getJSONArray("content")
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            if (c.optString("type") == "tool_use") {
                return ToolCall(c.getString("id"), c.getString("name"), c.getJSONObject("input"))
            }
        }
        throw Exception("AI did not choose an action")
    }

    private fun openai(system: String, turns: List<Turn>): ToolCall {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        turns.forEachIndexed { i, t ->
            val last = i == turns.size - 1
            when (t.kind) {
                Turn.USER -> msgs.put(
                    JSONObject().put("role", "user").put(
                        "content",
                        if (last && t.image != null) openaiImage(body(t, last), t.image) else body(t, last)
                    )
                )
                Turn.CALL -> msgs.put(
                    JSONObject().put("role", "assistant").put("content", JSONObject.NULL).put(
                        "tool_calls",
                        JSONArray().put(
                            JSONObject().put("id", t.id).put("type", "function").put(
                                "function",
                                JSONObject().put("name", t.name).put("arguments", t.args.toString())
                            )
                        )
                    )
                )
                else -> {
                    msgs.put(JSONObject().put("role", "tool").put("tool_call_id", t.id).put("content", body(t, last)))
                    if (last && t.image != null) {
                        msgs.put(
                            JSONObject().put("role", "user")
                                .put("content", openaiImage("Current screenshot after the action:", t.image))
                        )
                    }
                }
            }
        }
        val tools = JSONArray()
        for (d in Tools.all) {
            tools.put(
                JSONObject().put("type", "function").put(
                    "function",
                    JSONObject().put("name", d.name).put("description", d.desc).put("parameters", d.schema)
                )
            )
        }
        val req = JSONObject()
            .put("model", cfg.model)
            .put("tools", tools)
            .put("tool_choice", "required")
            .put("messages", msgs)

        val url = cfg.baseUrl.trimEnd('/') + "/chat/completions"
        val resp = JSONObject(post(url, mapOf("Authorization" to "Bearer " + cfg.apiKey), req.toString()))
        val msg = resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val calls = msg.optJSONArray("tool_calls")
        if (calls == null || calls.length() == 0) throw Exception("AI did not choose an action")
        val c = calls.getJSONObject(0)
        val fn = c.getJSONObject("function")
        val raw = fn.optString("arguments", "{}")
        return ToolCall(
            c.optString("id", "call_" + System.nanoTime()),
            fn.getString("name"),
            JSONObject(if (raw.isBlank()) "{}" else raw)
        )
    }

    private fun post(url: String, headers: Map<String, String>, json: String): String {
        var lastErr = ""
        for (attempt in 1..3) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 90000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                for ((k, v) in headers) conn.setRequestProperty(k, v)
                conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code >= 400) conn.errorStream else conn.inputStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code < 400) return text
                lastErr = "HTTP $code: " + text.take(300)
                if (code != 429 && code < 500) throw Exception(lastErr)
            } finally {
                conn.disconnect()
            }
            Thread.sleep(2000L * attempt)
        }
        throw Exception(lastErr)
    }
}
